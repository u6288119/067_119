import 'package:flutter/material.dart';
// import 'package:flutter_auth/components/rounded_button.dart';

class WelcomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return MaterialApp(
      title: 'FIND CATEGORY',
      home: Scaffold(
        appBar: AppBar(
          title: Text('FIND CATEGORY'),
        ),
        body: Center(
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: <
              Widget>[
            Text(
              "FIND CATEGORY APPLICATION",
              style: TextStyle(
                  fontWeight: FontWeight.bold,
                  color: Colors.deepOrange[300],
                  fontSize: 40),
            ),
            SizedBox(height: size.height * 0.05),
            Container(
                child: Image.asset(
              'assets/images/icon.png',
              height: 250,
              width: 250,
            )),
            SizedBox(height: size.height * 0.05),
            TextButton(
                child: Text("LOG IN",
                    style:
                        TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
                style: ButtonStyle(
                    padding: MaterialStateProperty.all<EdgeInsets>(
                        EdgeInsets.all(15)),
                    foregroundColor:
                        MaterialStateProperty.all<Color>(Color(0xFFFF8A65)),
                    shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                        RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(25.0),
                            side: BorderSide(color: Color(0xFFFF8A65))))),
                onPressed: () => null),
            SizedBox(height: 10),
            TextButton(
                child: Text("SIGN UP",
                    style:
                        TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
                style: ButtonStyle(
                    padding: MaterialStateProperty.all<EdgeInsets>(
                        EdgeInsets.all(15)),
                    foregroundColor:
                        MaterialStateProperty.all<Color>(Color(0xFFFF8A65)),
                    shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                        RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(25.0),
                            side: BorderSide(color: Color(0xFFFF8A65))))),
                onPressed: () => null),
          ]),
        ),
      ),
      theme: ThemeData(primarySwatch: Colors.deepOrange),
    );
  }
}
